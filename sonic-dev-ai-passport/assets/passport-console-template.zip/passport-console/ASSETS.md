# 素材与来源

- `public/assets/official-mark.png`：https://ai-passport.folotoy.cn/favicon.png ，2026-11-07 获取，原官方图标；归原权利人所有，用于 AI Passport 设备配置界面，不宣称获得商标所有权。
- 字标：官网本身使用文本 `AI PASSPORT` 与绿色 `//`，沿用该形式。
- 图标库：`@phosphor-icons/react`，版本由 package-lock.json 锁定，遵守其包内许可。
- React/Vite 及其依赖遵守各包许可；系统中文字体不随模板分发。
- 布局依据用户确认的两张设计稿，代码源自工作区 passport-console 原型；无外网字体或运行时品牌资源请求。
